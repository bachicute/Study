class A:
  def fun(): # Noncompliant {{Function def.}}
#     ^^^
    pass
