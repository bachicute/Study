Sonar Custom Rules Examples [![Build Status](https://travis-ci.org/SonarSource/sonar-custom-rules-examples.svg?branch=master)](https://travis-ci.org/SonarSource/sonar-custom-rules-examples)
==========

This repository contains project examples you can directly clone to bootstrap your own project to write custom rules for COBOL, Java, JavaScript, PHP, Python and RPG.

Related documentation is there: https://docs.sonarqube.org/latest/extend/adding-coding-rules/

### License

Copyright 2016-2019 SonarSource.

Licensed under the [GNU Lesser General Public License, Version 3.0](http://www.gnu.org/licenses/lgpl.txt)
