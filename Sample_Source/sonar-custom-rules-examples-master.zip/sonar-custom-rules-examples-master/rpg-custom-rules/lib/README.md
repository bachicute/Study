This directory should contain sonar-rpg-plugin-2.0.jar.
