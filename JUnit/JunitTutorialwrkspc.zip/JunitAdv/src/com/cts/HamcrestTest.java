package com.cts;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.hamcrest.CoreMatchers.nullValue;
//import static org.hamcrest.CoreMatchers.;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

public class HamcrestTest {
	@Test   
	public void Readability()    
	{   
		String expected="my_expected_value";
		String actual="my_expected_valuerr";
		//assertEquals 
	//	assertEquals(expected, actual);
		assertThat(actual, is(equalTo(expected)));
		
		//assertFalse 
	 	//assertFalse(expected.equals(actual));
		//assertThat(actual, is(not(equalTo(expected))));
	}   
	
	@Test   
	public void FailureMessages()    
	{   
		String expected="abc";
		String actual="def";
		
	//  	assertTrue(expected.contains(actual)); 
	// assertThat(actual, containsString(expected)); 
		 
	}   
	@Test   
	public void Flexibility()    
	{   
		 
		assertThat("test2", anyOf(is("test2"), containsString("fddf")));
	 
		 
	} 
	 
	@Test   
	public void testHasItem()    
	{   
		 List<String>myList= new ArrayList<String>();
		 myList.add("Item1");
		 myList.add("Item2");
		 myList.add("Item3");
		 int value=0;
		 List<String>myList2= new ArrayList<String>();
		// assertThat(myList,sameInstance(myList2));
		 assertThat(myList,hasItems("Item1" ));//"Item1","Item2","Item3"
		 assertThat("test2", anyOf(is("test2"), is("test3")));
	 //	 assertThat(myList,nullValue());
		 // assertThat(myList,lessThan(0));
		 
	 
		 
	} 
}
