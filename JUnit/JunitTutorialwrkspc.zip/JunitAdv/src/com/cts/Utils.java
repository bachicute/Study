package com.cts;

public class Utils {

	public static int add(int x, int y) {
		return x+y;
	}
}

