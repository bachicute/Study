package com.cts;
 
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import org.junit.jupiter.api.Test;
public class AssertThatBasics {
/*	@Test   
	public void Anything()    
	{        
		assertThat(calculator.subtract(4, 1), is(equalTo(3)));
	}   */
	@Test   
	public void _Null()   
	{        
		
		String tested = null;      
		assertThat("Is it null?", tested, nullValue());    
	}   
	@Test   
	public void _NotNull()   
	{    
		String tested = "DD";      
		assertThat("Is it not null?", tested, notNullValue());   
	}  
	@Test   
	public void _Anything()    
	{     
		String tested = "Hello matcher logic";      
		String check = "matcher";       
		assertThat("Anything passes", tested, anything(check));   
	}  
	@Test   
	public void _CloseTo()   
	{    
		double actual= 1.05;
		double expected=1.0;
		double delta=0.05;
		assertThat(actual, is(closeTo(expected, delta)));
	}  
}
