package com.cts;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
public class FileComparison {

	@Execution(ExecutionMode.CONCURRENT)
	@TestFactory
	 Stream<DynamicTest> dynamicTestsExample() {
		List<Integer> input1List = Arrays.asList(1,2,3);
		List<Integer> input2List = Arrays.asList(10,20,30);
		
		List<DynamicTest> dynamicTests = new ArrayList<>();
		
		for(int i=0; i < input1List.size(); i++) {
			int x = input1List.get(i);
			int y = input2List.get(i);
			DynamicTest dynamicTest = DynamicTest.dynamicTest("Dynamic Test for MyUtils.add("+x+","+y+")", () 
					->{
						assertEquals(x+y,Utils.add(x,y));
						 System.err.println(Thread.currentThread().getName());
					  });
			dynamicTests.add(dynamicTest);
		}
		
		return dynamicTests.stream();
	}
}
