package com.cts;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assume.assumeNotNull;
import static org.junit.Assume.assumeThat;

import org.junit.jupiter.api.Test;

public class testAssumption {
	@Test
    void testAssumption()  
	{
		String firstPart="tapas";
		String secondPart=null;// "mondal";
		   assumeNotNull(firstPart, secondPart);
	
	        
 //    assumeThat(firstPart, notNullValue());
  assumeThat(secondPart, notNullValue());
     
		String concat =  EmailIdUtility.createEmailID(firstPart,secondPart);
		 System.out.println(String.format("Actual: %s \n", concat));
		assertThat(concat, is(allOf(containsString(firstPart), containsString(secondPart))));
	}
	 
}
