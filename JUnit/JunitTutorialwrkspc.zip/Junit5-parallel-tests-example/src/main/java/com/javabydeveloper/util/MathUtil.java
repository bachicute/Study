package com.javabydeveloper.util;

public class MathUtil {
	
	public static int add(int num1, int num2) {
		for(int i=0;i<1000;i++)
        {
         	System.out.println("add::  "+i );
        }
		return num1 + num2;
	}
	
	public static int multiple(int num1, int num2) {
		for(int i=0;i<1000;i++)
        {
         	System.out.println("multiple::  "+i );
        }
		return num1 * num2;
	}
	
	public static boolean isEven(int num) {
		for(int i=0;i<1000;i++)
        {
         	System.out.println("isEven::  "+i );
        }
	    return num%2 == 0;
	}
	
	public static int devide(int num, int by) {
		for(int i=0;i<1000;i++)
        {
         	System.out.println("devide::  "+i );
        }
		return num/by;
	}
	
	public static boolean isPrime(int num) {
		 for(int i=0;i<1000;i++)
         {
          	System.out.println("isPrime::  "+i );
         }
		for(int i=2; 2*i<num; i++) {
	        if(num%i==0)
	            return false;
	    }
	    return true;
	}
}
