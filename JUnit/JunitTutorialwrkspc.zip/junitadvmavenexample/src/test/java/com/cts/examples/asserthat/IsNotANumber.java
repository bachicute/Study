package com.cts.examples.asserthat;
import org.hamcrest.Description; 
import org.hamcrest.Matcher; 
import org.hamcrest.TypeSafeMatcher;

public class IsNotANumber extends TypeSafeMatcher {

	  

	  public void describeTo(Description description) { 
	    description.appendText("not a number"); 
	  }

	  public static Matcher notANumber() { 
	    return new IsNotANumber(); 
	  }

	  @Override
		protected boolean matchesSafely(Object item) {
			// TODO Auto-generated method stub
		 
			return isNumeric(item);
			
		}
		private static boolean isNumeric(Object strNum) {
		    if (strNum == null) {
		        return false;
		    }
		    try {
		        double d = Double.parseDouble(strNum.toString());
		    } catch (NumberFormatException nfe) {
		        return false;
		    }
		    return true;
		}

	} 