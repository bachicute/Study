package com.cts.examples.cal;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.notNullValue;
//import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.notANumber;
import static org.hamcrest.Matchers.lessThan;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.hamcrest.Matchers.greaterThan;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


@TestMethodOrder(OrderAnnotation.class)
public class CalculatorTest {

	  Calculator calculator= null;
	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
		System.out.println("setUpBeforeClass:::");
		
	
	}

	@AfterAll
	public static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	public void setUp()  {
		System.out.println("setUp:::");
		calculator= new Calculator();
		System.out.println("setUp::: " + calculator);
	}

	@AfterEach
	public void tearDown()  {
	}

	@Test
	@Order(1)
	public void testSum() {
		System.out.println("testSum::: " + calculator);
		int result=	calculator.sum(2, 3);
		assertEquals(5,result);
	}

	@Test
	@Order(2)
	public void testSubtract() {
		int result=	calculator.subtract( 5, 3);
		assertEquals(2,result);
	}

	@Test
	public void testMultiplication() {
	 int result=	calculator.multiplication( 5, 3);
		assertEquals(15,result);
	}

	@Test
	@Order(3)
	public void testDivison() {
		 int result;
		try {
			result = calculator.divison( 10, 5);
			assertEquals(2,result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	  	@Test
	public void testDivison_Division_zero() {
		 int result;
		try {
			result = calculator.divison( 10, 0);
			assertEquals(2,result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}  
	  	 
	@Test
	public void testEqualIntegers() {
		boolean result=	calculator.equalIntegers(  3, 3);
		assertEquals(true,result);
	}
	 
	 @Test
	public void TypeSefty()
	{
	//	 assertEquals("123",123) ;//compile but fails
	 	//assertThat(123,is("123"));//
	}

	
	@Test   
	public void _CloseTo()   
	{    
		double actual= 1.03;
		double expected=1.0;
		double delta=0.05;
		assertThat(actual, is(closeTo(expected, delta)));
	}  
  
	@Test   
	public void _Null()   
	{        
		
		String tested = null;      
		assertThat("Is it null?", tested, nullValue());    
	}   
	@Test   
	public void _NotNull()   
	{    
		String tested = "DD";      
		assertThat("Is it not null?", tested, notNullValue());   
	}  
	@Test   
	public void _Anything()    
	{     
		String tested = "Hello matcher logic";      
		String check = "matcherss";       
		assertThat("Anything passes", tested, anything(check));   
	}  
	@Test   
	public void _LessThan()    
	{     
		 assertThat(3, lessThan(5 ) );
	}  
	
	@Test   
	public void _GreaterThan()    
	{     
		 assertThat( 5, greaterThan(3 ) );
	} 
	/* @Test
	public void customMatcher()
	{
		assertEquals(1 is(notANumber()));
	} */
}
