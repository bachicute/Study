package com.cts.examples.cal;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static com.cts.examples.asserthat.IsNotANumber.notANumber;
import com.cts.examples.cal.Calculator;
import com.cts.examples.cal.ICalculator;
public class AssertThatBasics {
	private static ICalculator calculator;
	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
		calculator= new Calculator();
	}
	@Test   
	public void Anything()    
	{        
		assertThat(calculator.subtract(4, 1), is(equalTo(3)));
	}   
	@Test   
	public void _Null()   
	{        
		
		String tested = null;      
		assertThat("Is it null?", tested, nullValue());    
	}   
	@Test   
	public void _NotNull()   
	{    
		String tested = "";      
		assertThat("Is it not null?", tested, notNullValue());   
		}  
	@Test   
	public void _Anything()    
	{     
		String tested = "Hello matcher logic";      
		String check = "matcher";       
		assertThat("Anything passes", tested, anything(check));   
	}  
	
	@Test
	public void customMatcher()
	{
		assertThat(1.0, is(notANumber()));
	}
}