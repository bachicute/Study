package com.cts;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;
import org.junit.rules.TemporaryFolder;
import org.junit.rules.Verifier;
public  class RuleTest {
	@Rule
	public TemporaryFolder tmpFolder = new TemporaryFolder();
	@Rule
	public final ErrorCollector errorCollector = new ErrorCollector();
	private List messageLog = new ArrayList();
	 
	@Rule
	public Verifier verifier = new Verifier() {
	    @Override
	    public void verify() {
	          assertTrue("Message Log is not Empty!", messageLog.size()==1);
	   //   assertTrue("Message Log is not Empty!",messageLog.isEmpty());	
	    	
	    }
	};
	
	@Test //TemporaryFolder
	public void givenTempFolderRule_whenNewFile_thenFileIsCreated() throws IOException {
	    File testFile = tmpFolder.newFile("test-file.txt");
	 
	    assertTrue("The file should have been created: ", testFile.isFile());
	    assertEquals("Temp folder and test file should match: ", 
	      tmpFolder.getRoot(), testFile.getParentFile());
	}
	@Test //ErrorCollector
	public void givenMultipleErrors_whenTestRuns_thenCollectorReportsErrors() {
	    errorCollector.addError(new Throwable("First thing went wrong!"));
	      errorCollector.checkThat("Hello World", not(containsString("ERROR!")));
	  //   errorCollector.checkThat("Hello World",  containsString("ERROR!" ));
	    errorCollector.addError(new Throwable("Another thing went wrong!"));
	         
	    
	}
	@Test// Verifier
	public void givenNewMessage_whenVerified_thenMessageLogNotEmpty() {
	    // ...
	    messageLog.add("There is a new message!");
	}
	
}
