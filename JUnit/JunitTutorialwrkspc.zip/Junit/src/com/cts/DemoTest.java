package com.cts;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
public class DemoTest {

	@Test(timeout=500)
	public void testcase(){
		//db connectivity
		System.out.println("In testcase:: " );
		String str="Hello";
		assertEquals("Hello",str);
	}
	@Test
	public void testcase2(){
		//db connectivity
		System.out.println("In testcase2:: " );
		String str="Hello";
		assertEquals("Hello",str);
	}
	@Before
	public void initializeBefore()
	{
		//db connectivity
		System.out.println("initializeBefore:: " );
	}
	@After
	public void initializeAfter()
	{
		//db connectivity
		System.out.println("initializeAfter:: " );
	}
	@BeforeClass
	public static void initializeBeforeClass()
	{
		//db connectivity
		System.out.println("initializeBeforeClass:: " );
	}
	
	@AfterClass
	public static void initializeAfterClass()
	{
		//db connectivity
		System.out.println("initializeAfterClass:: " );
	}
	 
/*	
	@BeforeClass
	public static void initializeBeforeClass()
	{
		//db connectivity
		System.out.println("initializeBeforeClass:: " );
	}
	@AfterClass
	public static void initializeAfterClass()
	{
		//db connectivity
		System.out.println("initializeAfterClass:: " );
	}
	
	@Before
	public void initializeBefore()
	{
		//db connectivity
		System.out.println("initializeBefore:: " );
	}
	@After
	public void initializeAfter()
	{
		//db connectivity
		System.out.println("initializeAfter:: " );
	}*/
}
