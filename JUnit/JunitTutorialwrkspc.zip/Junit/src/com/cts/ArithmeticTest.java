package com.cts;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class ArithmeticTest {
	private int firstNumber;
	private int seccondNumber;
	private int expectedResult;
	private Arithmetic arithmetic;
	
	public ArithmeticTest(int firstNumber, int seccondNumber, int expectedResult) {
		super();
		 System.out.println("In Constructor:: ");
		this.firstNumber = firstNumber;
		this.seccondNumber = seccondNumber;
		this.expectedResult = expectedResult;
	}
	
	@Before
	   public void initialize() {
		arithmetic = new Arithmetic();
	   }
	
	 @Parameterized.Parameters
	   public static Collection primeNumbers() {
	      return Arrays.asList(new Object[][] {
	         { 1,2,3 },
	         { 11, 22,33 },
	         { 111, 222,333 },
	         { 10,11,21  } 
	      });
	   }
	 
	 @Test
	 public void testArithmeticTest()
	 {
		 int res= arithmetic.sum(firstNumber,seccondNumber);
		 System.out.println("Sum of two numbers:: " + res    + "     expectedResult:: " + expectedResult);
		 assertEquals(expectedResult,res);
	 }
	 
}