package com.cts;
import org.junit.Test;
public class TestException {
	 @Test(expected = NullPointerException.class)
	 	public void whenExceptionThrown_thenExpectationSatisfied() {
		    String test =null;
		    test.length();
		}
		 
		 @Test(expected = ArithmeticException.class)
		 	public void DividedByZeroException() {
			    int n=1;
			    int d=1;
			    int r= n/d;
			}
}
