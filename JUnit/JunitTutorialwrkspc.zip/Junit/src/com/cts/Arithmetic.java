package com.cts;

public class Arithmetic {
	public int sum(int a,int b)
	{
		return a+b;
	}
}
