package com.cts;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Result result= JUnitCore.runClasses(DemoTest.class);
		
		for(Failure failure: result.getFailures())
		{
			System.out.println("Failure:: "+failure.getMessage());
		}
		System.out.println("Result:: "+ result.wasSuccessful());
	}

}
