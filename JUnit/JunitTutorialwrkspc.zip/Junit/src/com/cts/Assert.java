package com.cts;

import org.junit.Test;
import static org.junit.Assert.*;
public class Assert {
	@Test
	public void testAssert()
	{
		String str=  new String("cts");
		String str1=new String("cts");
		String str2=null;
		int val=5;
		int val1=6;
		String str3= "cts";
		String str4="cts";
		
		//check for equal;
		assertEquals(str,str1);
		//check for true
		assertTrue(val<val1);
		//check for false
		assertFalse(val>val1);
		//check if it is not null
	///  assertNotNull(str2);
		//check if it is null
		assertNull(str2);
		//check if the reference is to the same object
		assertSame(str3,str4);
		//not same
	 	assertNotSame(str,str3);
	 	 
	}
}
